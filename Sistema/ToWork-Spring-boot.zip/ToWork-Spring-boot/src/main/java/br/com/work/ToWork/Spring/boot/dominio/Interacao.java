package br.com.work.ToWork.Spring.boot.dominio;

public class Interacao extends Publicacao {

    //Atributos
    private Integer idInteracao;
    //private Date dataInteracao;
    private String nomeDeQuemInteragiu;

    //Construtor

    /*public Interacao(String nome, String email, String senha, String cpf, String especialidade, Integer idPublicacao, Integer totalInteracao, Integer idInteracao, String nomeDeQuemInteragiu) {
        super(nome, email, senha, cpf, especialidade, idPublicacao, totalInteracao);
        this.idInteracao = idInteracao;
        this.nomeDeQuemInteragiu = nomeDeQuemInteragiu;
    }*/


    //Métodos

}
