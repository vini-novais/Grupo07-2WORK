public class Investidor {

    private String cnpj;
    private String cnpjEmpresa;



}
