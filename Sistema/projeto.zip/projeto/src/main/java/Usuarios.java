public abstract class Usuarios {

    private String nome;
    private  String email;
    private String senha;
    private String cpf;
    private Boolean usuariodev;



}
