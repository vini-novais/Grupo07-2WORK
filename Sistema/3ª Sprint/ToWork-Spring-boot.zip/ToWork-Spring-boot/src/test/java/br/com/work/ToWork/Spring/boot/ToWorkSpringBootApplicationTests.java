package br.com.work.ToWork.Spring.boot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ToWorkSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
