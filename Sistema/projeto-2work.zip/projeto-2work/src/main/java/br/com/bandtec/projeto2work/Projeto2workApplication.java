package br.com.bandtec.projeto2work;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Projeto2workApplication {

	public static void main(String[] args) {
		SpringApplication.run(Projeto2workApplication.class, args);
	}

}
