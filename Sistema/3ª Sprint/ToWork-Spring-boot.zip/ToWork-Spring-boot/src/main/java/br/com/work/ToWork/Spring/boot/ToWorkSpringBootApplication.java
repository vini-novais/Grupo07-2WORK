package br.com.work.ToWork.Spring.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ToWorkSpringBootApplication {

    public static void main(String[] args) {
        SpringApplication.run(ToWorkSpringBootApplication.class, args);
    }

}