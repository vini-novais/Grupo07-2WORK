public class Publicacao {
}
