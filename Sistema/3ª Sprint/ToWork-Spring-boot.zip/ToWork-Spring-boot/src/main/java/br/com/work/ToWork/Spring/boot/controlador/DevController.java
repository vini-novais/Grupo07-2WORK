package br.com.work.ToWork.Spring.boot.controlador;

import br.com.work.ToWork.Spring.boot.dominio.Dev;
import br.com.work.ToWork.Spring.boot.repositorio.DevRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@CrossOrigin
@RequestMapping("/upload")
public class DevController {

    @Autowired
    private DevRepository devRepository;

    @PatchMapping("/foto/{id}")
    public ResponseEntity patchFoto(
            @PathVariable int id,
            @RequestParam MultipartFile foto
    ) throws IOException {
        if (devRepository.existsById(id)) {
            Dev dev = devRepository.findById(id).get();
            byte[] novaFoto = foto.getBytes();
            dev.setFoto(novaFoto);
            devRepository.save(dev);
            return ResponseEntity.status(200).build();
        } else {
            return ResponseEntity.status(404).build();
        }
    }

    @GetMapping("foto/{id}")
    public ResponseEntity getFoto(@PathVariable int id) {
        if (devRepository.existsById(id)) {
            Dev dev = devRepository.findById(id).get();
            return ResponseEntity.status(200).header("content-type", "image/png")
                    .body(dev.getFoto());
        } else {
            return ResponseEntity.status(404).build();
        }
    }
}