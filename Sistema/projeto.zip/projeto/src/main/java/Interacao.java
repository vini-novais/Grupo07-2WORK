import java.util.Date;

public class Interacao {

    private Integer idInteracao;
    private Integer totalInteracao;
    private Date dataInteracao;

    

}
