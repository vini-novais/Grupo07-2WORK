package br.com.bandtec.projeto2work;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Projeto2workApplicationTests {

	@Test
	void contextLoads() {
	}

}
