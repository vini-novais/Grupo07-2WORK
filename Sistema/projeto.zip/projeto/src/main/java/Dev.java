public class Dev extends Usuarios{

    private String especialidade;



}
