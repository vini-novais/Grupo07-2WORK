package br.com.work.ToWork.Spring.boot.dominio;

public interface Iterator<T> {
    Object next();

    Boolean hasNext();
}